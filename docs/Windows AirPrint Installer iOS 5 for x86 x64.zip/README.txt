AirPrint for Windows - Including iOS 5 Fix, V.2

After extraction you should have three files:
- "AirPrint_Installer.exe"
- "AirPrint iOS 5 FIX - 32Bit.reg"
- "AirPrint iOS 5 FIX - 64Bit.reg"

1. Run "AirPrint_Installer.exe" and then click on "Install AirPrint Service".

2. Run the "AirPrint iOS 5 FIX - 32Bit.reg" or  "AirPrint iOS 5 FIX - 64Bit.reg" to install the iOS 5 fix  (Choose the correct file for you operating system, 32 Bit or 64 Bit Windows).

3. Go back to "AirPrint_Installer.exe", make sure "Service Startup" is set to "Auto" and click "Start".

4. Restart computer.

If there is a locked icon next to the printer on the iOS device enable the guest account in windows. In the "AirPrint_Installer.exe" choose to use Guest Account Auth and tick the "Enable Guest Account" box. Then click "Update". You will then need to restart. If you want windows to automatically log you in on startup, type "netplwiz" into the start menu search box, hit enter. Uncheck the box that says �Users must enter a user name and password to use this computer�, and then hit Apply. You�ll see a username and password box. Enter in the appropriate information here and hit OK..

Packaged by Jason Houghton, JasonHoughton.com
Registry FIX by Jason Houghton, credits for the Installer go to http://www.elpamsoft.com/
Thank You.
